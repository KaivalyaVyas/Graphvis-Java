package kDTree;

public class KdtreeTemp {

	
	//find total number of points
	// find total number of levels
	//have for loop  0 to n-1
	   //if x then(i even)
	      //inner for loop--- for even number take medain of X and call method split x --> returns total 2^(level+1) number splitted in 1Leftset+1 right set sets use those in split Y

	//if y then(i odd )
	      //inner for loop--- for odd number take median of Y and call method split y --->returns 2^(level+1) number splitted in 1Leftset+1 right set sets use those in split X
	
	public static void main(String args[])
	{
		for(int i = 0;i<3;i++)
		{
			int x = 2^(i+1);
			for(int k=0;k<x;k++)
			{
				
			}
		}
			
	}
	
	
	
	
	
}
