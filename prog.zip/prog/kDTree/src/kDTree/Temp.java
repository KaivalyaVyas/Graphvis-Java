package kDTree;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Temp extends JApplet implements ActionListener
{
    int myArr[] = {79, 23, 122};
    String first[] = {"Paul", "Mark", "Kelly"};
    String last[] = {"Wyrick", "Wirtz", "Kirk"};
    String title[] = {"RIM RSM", "DM", "Building Supervisor"};
    JTextField name = new JTextField(20);
    JTextField jobTitle = new JTextField(20);
    JButton click = new JButton("Click after entering name");
    JLabel nam = new JLabel("Enter name here:");
    JLabel jt = new JLabel("Job title appears here");
    JLabel nf = new JLabel("Employee not found");
    Container myCon = getContentPane();
     
    public void init()
    {
        myCon.add(nam);
        myCon.add(name);
        myCon.add(click);
        myCon.add(jt);
        myCon.add(jobTitle);
        nam.setLocation(0, 0);
        name.setLocation(0, 50);
        click.setLocation(0, 100);
        jt.setLocation(0, 150);
                            
        click.addActionListener(this);
     
    }
    public void actionPerformed(ActionEvent e)
    {
        String wholeName = name.getText();
         
     int found = 0; 
     boolean myBool = false;
        for(int j = 0; j < first.length; j++)
        {
             
            for(int i = 0; i < first[j].length(); i++)
            {
                if(wholeName.charAt(i) != first[j].charAt(i))
                {
                    
                }
                else
                {
                   myBool = true;
                   found = j;
                   break;
                }
            }
        }
         
        if(myBool == false)
        {
            myCon.add(nf);
            validate();
             
        }
        else
        {
            jobTitle.setText(title[found]);
        }
         
    }
             
}