package kDTree;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JPanel;

public class Simple2DtreeSupport extends JPanel {
	static ArrayList<String> a = new ArrayList<String>();
	
	  protected void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        Graphics2D g2 = (Graphics2D)g;
	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	                            RenderingHints.VALUE_ANTIALIAS_ON);
	      /*  int w = getWidth();
	        int h = getHeight();
	        // Draw ordinate.
	        g2.draw(new Line2D.Double(PAD, PAD, PAD, h-PAD));
	        // Draw abcissa.
	        g2.draw(new Line2D.Double(PAD, h-PAD, w-PAD, h-PAD));
	        double xInc = (double)(w - 2*PAD)/(data.length-1);
	        double scale = (double)(h - 2*PAD)/getMax();*/
	        // Mark data points.
	        int x ;
	        System.out.println("Size of A "+a.size());
	        g2.setPaint(Color.red);
	        
	        for(int i = 0; i<a.size();i++)
	        {
	        	g2.setPaint(Color.black);
	        	Random rand = new Random();
	        	float r = rand.nextFloat();
	        	float g1 = rand.nextFloat();
	        	float b = rand.nextFloat();
	        	
	        	Color randomColor = new Color(r, g1, b);
	        	/*
	        	ArrayList<Color> usedColours = new ArrayList();
	        	int xy = 0;
	        	for(int l=0;l<=usedColours.size();i++)
	        	{
	        		if(usedColours.size() >0 && usedColours.get(l) ==  randomColor)
	        		{
	        			xy = 1;
	        		}
	        		else
	        		{
	        			usedColours.add(randomColor);
	        			xy = 0;
	        		}
	        	}*/
	        	
	        	
	          String[] s1 = a.get(i).split(",",2);
	         g2.setColor(randomColor);
	        //g2.setColor(Color.blue);
	        	g2.fill(new Ellipse2D.Double(Integer.parseInt(s1[0].toString()), Integer.parseInt(s1[1].toString()), 5, 5));
	        	
	        	//g2.drawLine(Integer.parseInt(s1[0].toString()),0,Integer.parseInt(s1[0].toString()), 500);
	        }
	        
          //g2.fill(new Ellipse2D.Double(250, 95, 5, 5));
          //g2.fill(new Ellipse2D.Double(250, 85, 5, 5));
          //g2.fill(new Ellipse2D.Double(250, 75, 5, 5));
          
	       /* for(int i = 0; i < data.length; i++) {
	            double x = PAD + i*xInc;
	            double y = h - PAD - scale*data[i];
	
	            
	        }*/
	    }
	

	  public ArrayList<String> AddPoints(String s)
	  {
		  // a = new ArrayList<String>();
		  a.add(s);
//		  Graphics G = new Graphics();
//		  paintComponent(G);
		  
		  return a;
	  }
	  
	  
}
