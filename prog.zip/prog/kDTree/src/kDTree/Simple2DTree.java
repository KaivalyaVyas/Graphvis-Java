package kDTree;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;




public class Simple2DTree extends JPanel {
	
	
	 public static void main(String[] args) {
	        JFrame f = new JFrame();
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	       
	        //System.out.println("Please add the 10 points in X,Y format");
	        Scanner sc = new Scanner(System.in);
	        
	        Simple2DtreeSupport s = new Simple2DtreeSupport();
	        for(int i=1;i<=2;i++)
	        {
	        	System.out.println("Please add the 5 points in X,Y format");
	        String ip = 	sc.next();
	        	ArrayList<String> a =  s.AddPoints(ip);
	        }
	      
	        
	        f.add(new Simple2DtreeSupport());
	        f.setSize(500,500);
	        f.setLocation(200,200);
	        f.setVisible(true);
	        
	    }
	 
	 
}


