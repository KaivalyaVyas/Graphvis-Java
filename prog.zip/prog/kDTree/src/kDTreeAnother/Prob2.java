package kDTreeAnother;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Prob2 {
	
	public static void main (String args[])
	{
		
		Map<String,String>myMap = new HashMap<String,String>();

	//	myMap.put("Subordinate", "Supervisor");
		
		myMap.put("Mary", "Frank");
		myMap.put("Sam", "Frank");
		myMap.put("Bob", "Mary");
		myMap.put("John", "Bob");
		myMap.put("X", "John");

		myMap.put("Sam", "Mary");
		myMap.put("Rat", "Sam");
		myMap.put("Katy", "Sam");
		

		myMap.put("Y", "Katy");
	
		String H1 = new Prob2().findHirarchy("Y",myMap);
		String H2 = new Prob2().findHirarchy("X",myMap);
		System.out.println("Hirarchy1.."+H1);
		System.out.println("Hirarchy2.."+H2);
		
	/*	List<String> Hirarchy1 = new ArrayList<String>(Arrays.asList(H1.split("|")));
		List<String> Hirarchy2 = new ArrayList<String>(Arrays.asList(H2.split("|")));
		
		for (int counter = 0; counter < Hirarchy1.size(); counter++) { 		      
	          System.out.println("AL1"+Hirarchy1.get(counter)); 		
	      }   
		
		for (int counter = 0; counter < Hirarchy2.size(); counter++) { 		      
	          System.out.println("AL2"+Hirarchy2.get(counter)); 		
	      }   
		
		*/
		
/*		for(Map.Entry<String, String> entry : myMap.entrySet()){
			if(entry.getValue() == "Vyas"){
				System.out.println(entry.getKey());
			}
		}
*/		
	}
	
	public  String  findHirarchy(String s,Map<String,String> m)  
	{
		String h = "";
	
		if(m.containsKey(s))
		{
			
			String newKey = m.get(s);
			h = h.concat(newKey).concat("|").concat(new Prob2().findHirarchy(newKey, m));
			
		}
		else  // fight with boss in else
		{
			h =s;
		}
		
		return h;
	}

}
