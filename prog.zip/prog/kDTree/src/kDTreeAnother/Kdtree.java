package kDTreeAnother;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Kdtree extends JPanel {

	int tempsizeL;
	int tempsizeR;
	int temp = 0;
	int level = 0;
	static	ArrayList<Integer> meanList = new ArrayList<Integer>();
	static	ArrayList<Integer> meanListY = new ArrayList<Integer>();
	static Set<Pair> s = new HashSet<Pair>();
	static JFrame jfm;
	
static	ArrayList<Set> al = new ArrayList<Set>();
static	ArrayList<Set> NeaserstLIst = new ArrayList<Set>();
static	ArrayList<Set> NeaserstLIstFinal = new ArrayList<Set>();
	public static void main(String args[])
	{
	
		
	Pair p = new Pair();
	p.setX(1);
	p.setY(5);
	Pair p1 = new Pair();
    p1.setX(10);
    p1.setY(31);
    Pair p2 = new Pair();
	p2.setX(22);
	p2.setY(42);
	Pair p3 = new Pair();
    p3.setX(12);
    p3.setY(13);
	Pair p4 = new Pair();
    p4.setX(17);
    p4.setY(37);
	Pair p5 = new Pair();
    p5.setX(170);
    p5.setY(370);
    Pair p6 = new Pair();
    p6.setX(10);
    p6.setY(10);
    
    Pair p7 = new Pair();
    p7.setX(310);
    p7.setY(200);
    
    Pair p8 = new Pair();
    p8.setX(150);
    p8.setY(40);
	
    
    Pair p9 = new Pair();
    p9.setX(250);
    p9.setY(100);
	
    
    Pair p10 = new Pair();
    p10.setX(15);
    p10.setY(400);
	
    Pair p11 = new Pair();
    p11.setX(115);
    p11.setY(40);
    
    
    Pair p12 = new Pair();
    p12.setX(215);
    p12.setY(240);
    
	
	s.add(p);
	s.add(p1);
	s.add(p2);
	s.add(p3);
	s.add(p4);
	s.add(p5);
	s.add(p6);
	s.add(p7);
	s.add(p8);
	s.add(p9);
	s.add(p10);
	//s.add(p11);
	//s.add(p12);
	Set<Pair> op = new HashSet<Pair>();
op = new Kdtree().buildtree(0,s,0);
System.out.println("Array List"+al.size());
for(int i=0;i<al.size();i++)
{
Collection cn =	al.get(i);
Iterator it = cn.iterator();
//for(int k=0;it.hasNext();i++)
//{
	 Pair pp = (Pair)it.next();
	//System.out.println("Set valueX"+pp.getX());
	//System.out.println("Set valueY"+pp.getY());
//}
	
}



 jfm = new JFrame();
jfm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
jfm.add(new Visulization());
jfm.setSize(500,500);
jfm.setLocation(200,200);
jfm.setVisible(true);

jfm.addMouseListener(new MouseAdapter() {
    public void mouseClicked(MouseEvent e) {
    	
    	//  System.out.println("KDV"+meanList);
    	 // System.out.println("KDV"+meanListY);
    	meanList.removeAll(meanList);
    	meanListY.removeAll(meanListY);
        System.out.println("mouse coordinates"+e.getPoint());
       
        Pair pClicked = new Pair();
        pClicked.setX(e.getX());
        pClicked.setY(e.getY());
       // System.out.println("size of S before "+s.size());
        s.add(pClicked);
      //  System.out.println("size of S after "+s.size());
              

      
        //System.out.println("al size"+al.size());
        al.removeAll(al);
        Set<Pair> op = new HashSet<Pair>();
        op = new Kdtree().buildtree(0,s,0);
        
        //System.out.println("KDV"+meanList);
  	  //System.out.println("KDV"+meanListY);
       // System.out.println("al size"+al.size());
       // System.out.println("Array List"+al.size());
        for(int i=0;i<al.size();i++)
        {
        	
        Collection cn =	al.get(i);
        Iterator it = cn.iterator();
        while(it.hasNext()){
//        for(int k=0;it.hasNext();i++)
  //      {
        	 Pair pp = (Pair)it.next();
        //	System.out.println("Set valueX"+pp.getX());
        //	System.out.println("Set valueY"+pp.getY());
            	
        	if(pp.getX()==e.getPoint().x && pp.getY()==e.getPoint().y &&  i<al.size()-1 && i>0)
        	{
        		if(i>0 && i< al.size()-1){
        		NeaserstLIst.add(al.get(i-1));
        		NeaserstLIst.add(al.get(i+1));
        		}
        		
        		/*if(i==0)
        		{
        			NeaserstLIst.add(al.get(i+1));
        		}
        		if(i==al.size())
        		{
        			NeaserstLIst.add(al.get(i-1));
        		}*/
        		System.out.println("Test 0 Previous");
        	
         
        		
        	}
        	
        	if(pp.getX()==e.getPoint().x && pp.getY()==e.getPoint().y  &&  i==al.size()-1)
        	{
        		NeaserstLIst.add(al.get(i-1));
        		NeaserstLIstFinal.add(al.get(i-1));
        		
        	//	System.out.println("Test 1 Previous");
        	
        	}
        	if(pp.getX()==e.getPoint().x && pp.getY()==e.getPoint().y  &&  i==0)
        	{
        		NeaserstLIst.add(al.get(i+1));
        		NeaserstLIstFinal.add(al.get(i+1));
        		//System.out.println("Test 2 Previous");
        	}
        	
        	
        //	System.out.println("* Previous NeaserstLIstFinal size"+NeaserstLIstFinal.size());
        //	System.out.println("* Previous NeaserstLIst size"+NeaserstLIst.size());
        }
       //assume below infinite distance
        double dist = 1000;
        double dist1 = 0;
        double dist2 = 0;
        for(int m=0;m<NeaserstLIst.size();m++)
        {
        Collection cn1 =	NeaserstLIst.get(m);
        Iterator it1 = cn1.iterator();
        
        Pair pp = (Pair)it1.next();
        if(m==0)
        {
        	dist1 = Math.sqrt((Math.abs(e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY())^2));
        }
        if(m==1)
        {
        	dist2 =  Math.sqrt((Math.abs(e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY())^2));
        }
       
        
        
        
        	//System.out.println("KDV");
        	//System.out.println(e.getPoint().x);
        	//System.out.println(e.getPoint().y);
        	//double dist = 10000000;
        	//System.out.println("KDVTEST"+Double.toString(dist)); 
        	//System.out.println("KDVTEST"+Double.toString(Math.sqrt(Math.abs((e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY())^2))));
        	if(dist >= Math.sqrt((Math.abs(e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY())^2))  && NeaserstLIst.size() == 2)
        	{
        		dist = Math.sqrt((Math.abs(e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY())^2));
        //		NeaserstLIstFinal.add(NeaserstLIst.get(m));	
        		//System.out.println("KDVTest1");
        		
        	}
        	
        	if(dist < Math.sqrt((Math.abs(e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY())^2))  && NeaserstLIst.size() == 2)
        	{
        	//	NeaserstLIstFinal.add(NeaserstLIst.get(m-1));
        		//System.out.println("KDVTest0");
        	}
        	if(NeaserstLIst.size() == 1)
        	
        	{
        		//NeaserstLIstFinal.add(NeaserstLIst.get(m));
        		//System.out.println("KDVTest-1");
        	}
        
        	dist = Math.sqrt(Math.abs((e.getPoint().x - pp.getX()))^2 + (Math.abs(e.getPoint().y - pp.getY()^2)));
        	 
        	
        
        
        if(dist1>dist2 && m ==1)
        {
        	//System.out.println("d2 radius"+dist2);
        	NeaserstLIstFinal.add(NeaserstLIst.get(1));
        }
        if(dist2>dist1 && m ==1)
        {
        	//System.out.println("d1 radius"+dist1);
        	NeaserstLIstFinal.add(NeaserstLIst.get(0));
        }
        if(NeaserstLIst.size() == 1 && m ==1)
        {
        	//System.out.println("d1 radius option3"+dist1);
        	NeaserstLIstFinal.add(NeaserstLIst.get(0));
        }
        if(dist2==dist1  && m ==1)
        {
        	//System.out.println("d1 radius option4 "+dist1);
        	NeaserstLIstFinal.add(NeaserstLIst.get(0));
        }
        	
        }      
        
        
        
        System.out.println("NeaserstLIstFinal size"+NeaserstLIstFinal.size());
        for(int n=0;n<NeaserstLIstFinal.size();n++)
        {
        	System.out.println("hii");
        	
        	if(n==NeaserstLIstFinal.size()-1){
        Collection cn2 =	NeaserstLIstFinal.get(n);
        Iterator it2 = cn2.iterator();
        double d;
        if(dist1>dist2)
        {
        d=dist2;	
        }
        else
        {
        	d= dist1;
        }
        Pair pp = (Pair)it2.next();
        System.out.println("Nearest Set valueX--as center"+pp.getX());
    	System.out.println("Nearest Set valueY--as center"+pp.getY());
    	System.out.println("And Radius "+d);
    	System.out.println(dist1+"---"+dist2+"And Radius "+d);
    	System.out.println(""+al.size());
    	if(d>0)
    	{
    Set<Pair> h =	findpointsInRadius(d,pp,al);
 
    System.out.println(""+h.size());
    Iterator iter = h.iterator();
    while (iter.hasNext()) {
    	Pair p = (Pair)iter.next();
        System.out.println("Nearest Point Coordinate for X is --->"+p.getX()+" and Y is --->"+p.getY());
    }
    
    	}
    	
    	
    	else
    	{
    		 System.out.println("for d 0 Nearest Point Coordinate for X is --->"+pp.getX()+" and Y is --->"+pp.getY());
    	}
    	
        	}
        }
       
        
        }
    
        
        
        
        
     //   jfm.getContentPane().add(comp);
       /* JFrame jfm1 = new JFrame();
        jfm1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       // jfm1.add(new Visulization());
        jfm1.setSize(500,500);
        jfm1.setLocation(200,200);
        jfm1.setVisible(true);
        */
    }
});

	}
	
	public Set<Pair> buildtree(int level,Set<Pair> s,int mideanParent)
	{
		Set<Pair> left = new HashSet();
		Set<Pair> right = new HashSet();
		Set<Pair> templ = new HashSet();
		Set<Pair> tempr = new HashSet();
		Set<Set> finalSet = new HashSet();
//System.out.println("in main level"+level);



if(s.size() == 1)
		{
			// return that point is leaf
		}
		else if(level%2 == 0)  //Divides X/Y is dividing parameter
		{
			
			//System.out.println("in even");
			int mean = 0;
			Collection c = s;
			  Iterator iter = c.iterator();
			for(int i = 0; iter.hasNext();i++)
			{
				Pair p = (Pair)iter.next();
				 mean = mean+ p.getX();
				  
				 
			}
			if(s.size()>0)
			{
			mean = (int)Math.floor(mean/s.size());
		//	System.out.println("mesnx"+mean);
			}  
			/* Calculate the median x-value.
		        Create a set of points (pointsLeft) that have x-values less than
		            the median.
		        Create a set of points (pointsRight) that have x-values greater
		            than or equal to the median*/
			  
			Collection c1 = s;
			  Iterator iter1 = c1.iterator();
			

		  for(int i = 0; iter1.hasNext();i++)
		  {
			  
			 Pair p = (Pair)iter1.next();
			  if(p.getX() >= mean)
			  {
				  //System.out.println("X value if "+p.getX());
					
				  tempr.add(p);
			  }
			  else
			  {
				//  System.out.println("X value else"+p.getX());
				  
				  templ.add(p);
			  }
		  }

			tempsizeL = templ.size();  
			tempsizeR = tempr.size();  
			// System.out.println("tempsizeR "+tempsizeR);
			 // System.out.println("tempsizeL "+tempsizeL);
		
			  
			  if(mideanParent != mean )
				{	
					//System.out.println("recursion L ");
				 
				  meanList.add(mean);
				 
				left = buildtree(level+1,templ,mean);
				right =buildtree(level+1,tempr,mean);
				temp = temp+1;
				 
				}
			  
			  if(templ.size() == 1)
				{
					//System.out.println("return L "+templ.size());
					finalSet.add(templ);
					System.out.println("level"+level);
					al.add(templ);
					
					
			           // return templ;
				}
				if(tempr.size() == 1)
				{
					
				//  	System.out.println("return R"+tempr.size());
				  	finalSet.add(tempr);
			        //return tempr;
				  	System.out.println("level"+level);
				  	al.add(tempr);
				  	
				 
		        	
				}
			  
			
		}
		else if(level%2 != 0)   //Divides X/Y is dividing parameter
		{
			//System.out.println("in odd");
			int meanY = 0;
			 Collection c = s;

			  Iterator iter = c.iterator();
			  
			  
			  for(int i = 0; iter.hasNext();i++)
				{
					
				  Pair p = (Pair)iter.next();
					 meanY = meanY+ p.getY();
					  
					 
				}

				if(s.size()>0)
				{	
				meanY = (int)Math.floor(meanY/s.size()) ;
				//System.out.println("mesny odd"+meanY);
				}

			/*  Calculate the median y-value.
        Create a set of points (pointsLeft) that have y-values less than
            the median.
        Create a set of points (pointsRight) that have y-values greater
            than or equal to the median.*/

				 Collection c1 = s;

				  Iterator iter2 = c1.iterator();
				  

			  for(int i = 0; iter2.hasNext();i++)
			  {
				  //System.out.println("Kaivalya ");
					
				 Pair p = (Pair)iter2.next();
				  if(p.getY() >= meanY)
				  {
					//  System.out.println("Y value if"+p.getY());
					//  System.out.println("Kaivalya >=");
					  templ.add(p);
				  }
				  else
				  {
				//	  System.out.println("Y value else"+p.getY());
					  //System.out.println("Kaivalya <");
						
					  tempr.add(p);
				  }
			  }

				  
				  
			  tempsizeR = tempr.size();
			  tempsizeL = templ.size();
			  //System.out.println("tempsizeR odd"+tempsizeR);
			 // System.out.println("tempsizeL odd"+tempsizeL);

				if(mideanParent != meanY  )
				{	
					System.out.println("at meanListY");
					 meanListY.add(meanY);
					//System.out.println("recursion R ");
					right =buildtree(level+1,tempr,meanY);
					left = buildtree(level+1,templ,meanY);
					temp = temp+1;
				}
				
				if(templ.size() == 1)
				{
					//System.out.println("return L "+templ.size());
					finalSet.add(templ);   
					//return templ;
					System.out.println("level"+level);
					al.add(templ);
				}
				if(tempr.size() == 1)
				{
					
				  	//System.out.println("return R"+tempr.size());
				  	finalSet.add(tempr);
			       // return tempr;
				  	System.out.println("level"+level);
				  	al.add(tempr);
				}
		}
	

/*
	if(templ.size() == 1)
	{
		System.out.println("return L "+templ.size());
            return templ;
	}
	if(tempr.size() == 1)
	{
		
	  	System.out.println("return R"+tempr.size());
        return tempr;
	}
	
	else
	{
						

		return null ;
	
	}
	*/
return null;
	}

public static Set<Pair> findpointsInRadius (double radius,Pair center,ArrayList<Set> alset)
{
	Set<Pair> s = new HashSet<Pair>();
	for(int k =0;k<alset.size();k++)
	{
	Collection cn3 =	alset.get(k);
    Iterator it3 = cn3.iterator();
    Pair Queryp = (Pair)it3.next();
 double	distance = Math.sqrt((Math.abs(Queryp.getX() - center.getX()))^2 + (Math.abs(Queryp.getY() - center.getY())^2));
   
 if(distance<radius)
 {
	 System.out.println("Point is inside radius"+distance);
	 s.add(Queryp);
 }
 if(distance>radius)
 {
	 System.out.println("Point is out of radius"+distance);
 }
 
	}
	return s;
}

}
