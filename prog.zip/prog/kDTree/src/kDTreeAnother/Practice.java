package kDTreeAnother;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Practice {

	
	


	    public static void main(String[] args) throws IOException {
	        // TODO Auto-generated method stub
	        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	        String s = in.readLine();
	        boolean flag =  false;
	        
	                
	        String[] value_split = s.split("\\|");
	        String[] value_derived = new String[value_split.length];
	        int[] arr = new int[value_split.length];
	        ArrayList<Integer> al = new ArrayList<Integer>();
	        
	        for (int i = 0; i < value_split.length; i++) {
	            value_derived[i] = value_split[i].replaceAll("[+.-^:,?'\"]", "").toLowerCase();
	        }
	        
	        for(int i=0;i<value_split.length;i++){
	            System.out.println(value_derived[i]);
	        }

	        /*for (int i = 0; i < value_split.length; i++) {
	            flag = false;
	            for (int j = 0; j < value_split.length; j++) {
	                                    // System.out.println("Yes"+"\t" +value_derived[j] +"\t"+value_derived[i]);
	                if (!(value_derived[j].contains(value_derived[i])) && !(i==j)) {
	                    System.out.println(value_split[i]);
	                    break;
	                }   
	            }
	        }*/
	        
	        for (int i = 0; i < value_derived.length; i++)
	        {
	        	int flag1 = 0;
	        	for(int j=0;j<value_derived.length; j++)
	        	{  //System.out.println(""+value_derived[j].contains(value_derived[i]) );
	        		//System.out.println(""+value_derived[j]+""+value_derived[j].length());
	        		//System.out.println(""+value_derived[i]+""+value_derived[i].length());
	        		//System.out.println("------------");
	        		if(!value_derived[j].contains("0")){
	        			
	        		if ((value_derived[j].contains(value_derived[i])) && !(i==j) && (value_derived[i].length() < value_derived[j].length())  ) {
	                    
	                     flag1 = flag1+1;
	                     System.out.println("flag"+flag1);
	                }   
	        		}	
	        	}
	        	
	        	if(flag1>0)
	        	{
	        		value_derived[i]= "0";
	        	}
	        }
	        
	        int temp2 = 0;
	        for(int i = 0; i < value_derived.length; i++)
	        {
	        	if(!value_derived[i].contains("0") && temp2==0){
	        		//System.out.println(""+value_derived[i]);
	        		
	        		temp2 = temp2+1;
	        	}
	        }
	        
	        for(int k =0;k<value_derived.length;k++)
	        {
	        	//System.out.println(""+value_derived[k]);
	        }
	        
	        Set<String> mySet = new HashSet<String>(Arrays.asList(value_derived));
	        
	        Iterator iter = mySet.iterator();
	        while (iter.hasNext()) {
	         // System.out.println(iter.next());
	        }

	    }

	



	
}
