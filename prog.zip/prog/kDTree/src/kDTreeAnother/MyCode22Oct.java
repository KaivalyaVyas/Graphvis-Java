package kDTreeAnother;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class MyCode22Oct {
	  public static void main(String args[] ) throws Exception {

		
		  Scanner sc = new Scanner(System.in);
	       // String input  = sc.nextLine(); // just starting to process input from line and taking input
	       // String temp  = sc.nextLine(); // just starting to process input from line 3
	        HashMap myData = new HashMap<String,HashMap<String,String>>();
	         HashMap tempMap = new HashMap<String,String>();
	        while(sc.hasNext()  )
	            {
	        	
	        	
	            String tempRow = sc.nextLine();
	            if(tempRow.equals("exit")) {
	                break;
	            }
	            String key1 = tempRow.substring(0,7);
	            String value1 = tempRow.substring(11,tempRow.length()); 
	            String temparray[] = value1.split(",",2);
	            String key2 = temparray[0];
	            String value2 = temparray[1];
	            
	            if(myData.containsKey(key1))
	                {
	                tempMap =  (HashMap)myData.get(key1);
	                
	                if(tempMap.containsKey(key2))
	                    {
	                    String oldValue = (String)tempMap.get(key2);
	                    oldValue = oldValue+","+value2;
	                    tempMap.remove(key2);
	                    tempMap.put(key2,oldValue);
	                    myData.put(key1,tempMap);
	                }
	                else
	                    {
	                    HashMap myInnerData1 = new HashMap<String,String>();
	                    myInnerData1 = (HashMap)myData.get(key1);
	                myInnerData1.put(key2,value2);
	                    myData.put(key1,myInnerData1);
	                }
	            }
	            else
	                {
	                HashMap myInnerData = new HashMap<String,String>();
	                myInnerData.put(key2,value2);
	                myData.put(key1,myInnerData);
	            }
	            System.out.println("inside while");
	        
	    }
	        
	         Set keys = myData.keySet();
	         HashMap prMap = new HashMap<String,String>(); 
	        
	   for (Iterator i = keys.iterator(); i.hasNext(); ) {
	       String key = (String) i.next();
	        prMap = (HashMap) myData.get(key);
	         Set Inrkeys = prMap.keySet();
	        for (Iterator j = Inrkeys.iterator(); j.hasNext(); ){
	          String Inrkey = (String) j.next() ; 
	          String Inrvalue = (String) prMap.get(Inrkey);    
	          System.out.println(key+"|"+Inrkey+"|"+Inrvalue);
	         
	   }
	   }
	      
		  
		  
		  
	  }
	  
}
