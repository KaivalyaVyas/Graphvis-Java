package kDTreeAnother;
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class MyCode {
	  public static void main(String args[] ) throws Exception {
	        Scanner sc = new Scanner(System.in);
	        //String temp  = sc.nextLine(); // just starting to process input from line 3
	        //String temp1  = sc.nextLine(); // just starting to process input from line 3
	        HashMap myData = new HashMap<String,HashMap<String,Integer>>();
	     
	        HashMap myInnerData = new HashMap<String,Integer>();
	        while(sc.hasNext())
	            {

	            String tempRow = sc.nextLine();
	            String key1 = tempRow.substring(0,7);
	            String value1 = tempRow.substring(11,tempRow.length()); 
	            String temparray[] = value1.split(",",2);
	            String key2 = temparray[0];
	            String value2 = temparray[1];
	            myInnerData.put(key2,Integer.valueOf(value2));
	            myData.put(key1,myInnerData);
	        
	            System.out.println("key1"+key1);
	            System.out.println("key2"+key2);
	            System.out.println("value1"+value1);
	            System.out.println("value2"+value2);
	        
	    }
	    }


}
