
package kDTreeAnother;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Prac3 {

	
	
	public static void main (String args[]) throws IOException
	{
		
	    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String s = in.readLine();
        boolean flag =  false;
        
                
        String[] value_split = s.split("\\|");
        String[] value_derived = new String[value_split.length];
        int[] arr = new int[value_split.length];
        ArrayList<Integer> al = new ArrayList<Integer>();
        /*
        for (int i = 0; i < value_split.length; i++) {
            value_derived[i] = value_split[i].toLowerCase();
            //value_derived[i] = value_split[i].replaceAll("[\\-]","X");
            value_derived[i] = value_split[i].replaceAll("\\s[^a-zA-Z]+", "").toLowerCase().trim();
        }
        */
        
        for (int i = 0; i < value_split.length; i++) {
           String mytext = value_split[i].replaceAll("[+.^:,?'\"]", "").toLowerCase();
            mytext = mytext.replaceAll("( )+", " ");
          //  mytext = mytext.replaceAll("-", " ");
            value_derived[i] = mytext;
            
            
        }
        
        for (int i = 0; i < value_derived.length; i++) {
            System.out.println(""+value_derived[i]);
        }
        System.out.println("-----");
        Set<String> mySet = new HashSet<String>(Arrays.asList(value_derived));
        String[] arrayString = mySet.toArray(new String[mySet.size()]);
        
        
        for (int i = 0; i < arrayString.length; i++) {
           // System.out.println(""+arrayString[i]);
        	for(int j = 0; j < arrayString.length; j++)
        	{
        	  if(arrayString[i].length()<arrayString[j].length() && arrayString[j].contains(arrayString[i]) & i!=j)
        	  {
        		  arrayString[i] = "0";
        	  }
        		
        	}
        }
        
        for (int i = 0; i < arrayString.length; i++)
        {
        	System.out.println(""+arrayString[i]);
        }
	
           
        }
		
	
}
