package kDTreeAnother;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import javax.swing.JPanel;

public class Visulization extends JPanel{
	
	 protected void paintComponent(Graphics g)
	 {
		 ArrayList<Set> aList =  Kdtree.al;
		 ArrayList<Integer> mean = Kdtree.meanList;
		 ArrayList<Integer> meanY = Kdtree.meanListY;
		 int min = 0;
			int max = 500;
		
		 int lookup ;
		 super.paintComponent(g);
	        Graphics2D g2 = (Graphics2D)g;
		 	g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		           RenderingHints.VALUE_ANTIALIAS_ON);
			g2.setPaint(Color.black);
			
			for(int i=0;i<aList.size();i++)
			{
			Collection cn =	aList.get(i);
			Iterator it = cn.iterator();
			//for(int k=0;it.hasNext();i++)
			//{
				 Pair pp = (Pair)it.next();
					g2.setColor(Color.red);
				 	g2.fill(new Ellipse2D.Double(pp.getX(),pp.getY(),2,2)); 
			//}
				
			}
			
			

			for(int i=0;i<mean.size();i++)   //ubhi line
			{
				//System.out.println("mean x "+mean.get(i));
				
				Random rand = new Random();
	        	float r = rand.nextFloat();
	        	float g1 = rand.nextFloat();
	        	float b = rand.nextFloat();
	        	
	        	Color randomColor = new Color(r, g1, b);
				
	        	
					g2.setColor(randomColor);
					
					
	       String s =  	findIntervalX(meanY,i,mean.get(i));
	     
	      String[] minMax = s.split(";");
	     int min1 = Integer.parseInt(minMax[0]);
	    int max1 =  Integer.parseInt(minMax[1]);
	      // System.out.println("Value of String "+s);
	        /*		if(i==0)
	        		{
	        			g2.setColor(Color.black);
	        			g2.drawLine(mean.get(i),0,mean.get(i),500);
	        		}
	        		if(i==1)
	        		{
	        			g2.setColor(Color.blue);
	        			g2.drawLine(mean.get(i),0,mean.get(i),23);
	        		}
	        		
	        		if(i==2)
	        		{
	        			g2.setColor(Color.red);
	        			g2.drawLine(mean.get(i),23,mean.get(i),500);
	        		}
	        		
	        		if(i==3)
	        		{
	        			g2.setColor(Color.green);
	        			g2.drawLine(mean.get(i),39,mean.get(i),500);
	        		}
	        		
				*/	
					
					g2.drawLine(mean.get(i),min1,mean.get(i),max1);
			        
//				 	g2.fill(new Ellipse2D.Double(mean.get(i),0,5,5)); 
				 	
					/*if(i==0)
					{
						g2.drawLine(mean.get(i),0,mean.get(i),500);
								
					}
					else
					{
						//g2.drawLine(min,meanY.get(i),max,meanY.get(i));
						g2.drawLine(mean.get(i),meanY.get(i),mean.get(i),meanY.get(i-1));	
					}
					*/
					
			}
			
			for(int i=0;i<meanY.size();i++)     //adi line
			{
				//System.out.println("mean y "+meanY.get(i));
				Random rand = new Random();
	        	float r = rand.nextFloat();
	        	float g1 = rand.nextFloat();
	        	float b = rand.nextFloat();
	        	
	        	Color randomColor = new Color(r, g1, b);
				
	        	String s =  	findIntervalY(mean,i,mean.get(i));
	        	 String[] minMax = s.split(";");
	    	     int min1 = Integer.parseInt(minMax[0]);
	    	    int max1 =  Integer.parseInt(minMax[1]);
	        //	System.out.println("value of string y"+s);
	        	
	        		g2.setColor(randomColor);
	        	
	        		
	        		/*
	        		if(i==0)
	        		{
	        			g2.setColor(Color.black);
	        			g2.drawLine(0,meanY.get(i),78,meanY.get(i));
	        		}
	        		if(i==1)
	        		{
	        			g2.setColor(Color.blue);
	        			g2.drawLine(7,meanY.get(i),78,meanY.get(i));
	        		}
	        		
	        		if(i==2)
	        		{
	        			g2.setColor(Color.red);
	        			g2.drawLine(78,meanY.get(i),500,meanY.get(i));
	        		}
	        		
	        		if(i==3)
	        		{
	        			g2.setColor(Color.green);
	        			g2.drawLine(160,meanY.get(i),500,meanY.get(i));
	        		}
	        		
	        		*/

	        		g2.drawLine(min1,meanY.get(i),max1,meanY.get(i));
	        	/*	if(i==0)
					{
						g2.drawLine(0,mean.get(i),500,mean.get(i));
								
					}
	        		
					else
					{
						
						g2.drawLine(mean.get(i),meanY.get(i),mean.get(i-1),meanY.get(i));	
					}*/
	        				}
		 
	 }

	 
	 
	 public String findIntervalX(ArrayList al,int i,int lkp_value)
	 {
		 String minMax = null;
		 int min=0;
		 int max=500;
		 int mindiff = -100000000;
		 int maxdiff = 100000000;
		 
		if(i==0)
		{
		  minMax = "0;500";	
		}
		 
		else
		{
			
		
			
			//if y[i] is highest
           //2nd highest number to 500
			
			
			//if y[i] is lowest
            // 0 to 2nd lowest number 	
			
			
			
			//if y[i] is between somewhere 
			//find interval by highest value lower then y[i] and lowest value higher then y[i]
			
			for(int l=0;l<i;l++)
			{
				//if number is smaller then given value 
				
				if(l<al.size() && i<al.size() && Integer.parseInt(al.get(l).toString()) <= Integer.parseInt(al.get(i).toString()))
				{
					
				
				   	
				   	
				   if(	mindiff < Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString()) )
				   {
					  
					   mindiff = Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString());
					  
					   min = Integer.parseInt(al.get(l).toString());
				   }
				   
				   	
				}
				
				else
				{
					
					
					
					if(l<al.size() && i<al.size() &&  maxdiff > Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString())  )
					{
						
						maxdiff = Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString());
						
						max= Integer.parseInt(al.get(l).toString());
						
					}
					
					
				  
					
				}
			}
			
			minMax = min+";"+max;	
		}
		
		 
		 
		 return minMax;
	 }
	 

	 public String findIntervalY(ArrayList al,int i,int lkp_value)
	 {

		 String minMax = null;
		 int min=0;
		 int max=500;
		 int mindiff = -100000000;
		 int maxdiff = 100000000;
		 
		 /*if(i==0)
		 {
			 minMax = "0,"+"lkp_value";
		 }*/
		 
		 if(i<al.size()-1)
		 {
				//if x[i] is highest
	           //2nd highest number to 500
				
				
				//if x[i] is lowest
	            // 0 to 2nd lowest number 	
				
				
				
				//if x[i] is between somewhere 
				//find interval by highest value lower then y[i] and lowest value higher then y[i]
			 
			 
			 
				
				for(int l=0;l<=i;l++)
				{
					
					//if number is smaller then given value 
					if(i<al.size()-1  && Integer.parseInt(al.get(l).toString()) <= Integer.parseInt(al.get(i+1).toString())    )
					{
						
					
					   	
					   	
					   if(	mindiff < Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString()) )
					   {
						  
						   mindiff = Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString());
						  
						   min = Integer.parseInt(al.get(l).toString());
					   }
					  
					}
					
					else
					{
						
						
						
						if(maxdiff > Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString())  )
						{
							
							maxdiff = Integer.parseInt(al.get(l).toString())-Integer.parseInt(al.get(i).toString());
							
							max= Integer.parseInt(al.get(l).toString());
							
						}
						
						
					  
						
					}
			
					minMax = min+";"+max;	
							
					
				
				}
				
			
			 
		 }
		 
		 else
		 {
			 if(Integer.parseInt(al.get(i).toString())<lkp_value)
			 {
			
				max = Integer.parseInt(al.get(i).toString()); 
			 }
			 else
			 {
				
				 min = Integer.parseInt(al.get(i).toString());
			 }
//			 minMax ="xyz";
			 minMax = min+";"+max;	
		 }
		 return minMax;
	 }
	 
}
