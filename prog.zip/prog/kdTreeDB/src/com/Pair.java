package com;

public class Pair {

}
