package com;

public class Kdtree {

}
